import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { getAuthUser, getHomePath } from "../utils/auth";

export default function RoleRoute({ allowedRoles = [] }) {
  const user = getAuthUser();

  if (!user) return <Navigate to="/login" replace />;

  const role = String(user.role || "").toUpperCase();
  const allowed = allowedRoles.map((r) => String(r).toUpperCase());

  if (!allowed.includes(role)) {
    return <Navigate to={getHomePath(user)} replace />;
  }

  return <Outlet />;
}
