import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { getAuthUser } from "../utils/auth";

/**
 * Replace this demo auth check with your real AuthContext/store.
 * Expected localStorage example:
 * localStorage.setItem("authUser", JSON.stringify({ id, role: "ADMIN" }))
 */
export default function ProtectedRoute() {
  const location = useLocation();
  const user = getAuthUser();

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return <Outlet />;
}
