export function getAuthUser() {
  try {
    return JSON.parse(localStorage.getItem("authUser") || "null");
  } catch {
    localStorage.removeItem("authUser");
    return null;
  }
}

export function getHomePath(user) {
  const role = String(user?.role || "").toUpperCase();

  if (role === "ADMIN") return "/admin/dashboard";
  if (role === "OWNER" || role === "STORE_OWNER") return "/owner/dashboard";
  return "/stores";
}

export function saveAuthUser(user) { localStorage.setItem("authUser", JSON.stringify(user)); }
export function clearAuthUser() { localStorage.removeItem("authUser"); }
