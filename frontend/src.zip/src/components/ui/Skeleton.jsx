import React from "react";

export default function Skeleton({ className = "" }) {
  return <div className={`animate-pulse rounded-lg bg-[#e5e7eb] ${className}`} />;
}