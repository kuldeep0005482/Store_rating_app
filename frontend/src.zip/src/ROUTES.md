# StoreRate Routes

Install React Router:

```bash
npm install react-router-dom
```

## Routes

| Path | Page | Role |
|---|---|---|
| `/login` | Login | Public |
| `/admin/dashboard` | Admin Dashboard | ADMIN |
| `/admin/users` | Admin Users List | ADMIN |
| `/admin/users/new` | Add User | ADMIN |
| `/admin/users/:id` | User Details | ADMIN |
| `/admin/stores` | Admin Stores List | ADMIN |
| `/admin/stores/new` | Add Store | ADMIN |
| `/stores` | Normal User Store Listing | USER |
| `/owner/dashboard` | Store Owner Dashboard | OWNER / STORE_OWNER |

`ProtectedRoute` currently reads `authUser` from localStorage. Replace this with your real authentication context/API state.
